/*
 * "$Id: smake.c,v 1.6 2013/08/02 13:22:09 senning Exp $"
 * 
 * Jonathan Senning <jonathan.senning@gordon.edu>
 * Gordon College
 *
 * This is a simple make utility that searches for a special string in a
 * file and then executes the command that follows that string.  The
 * following line will cause smake to rebuild itself using gcc:
 *
 * $Smake: gcc -Wall -O3 -o %F %f
 *
 * Based on the man page for smake(1) supplied on Sun systems, which
 * was written by S. McGeady (then of Tektronix, Inc, now a VP at Intel).
 * The only feature not implemented is the use of !<nnn> to represent the
 * character whose octal value is <nnn>.
 *
 * November 30, 1989:
 *      Original Version.  Compiles with Borland tcc program under MS-DOS
 *      and on Sun workstations.
 *
 * November 14, 1995:
 * 	Restructured code to be a little more ANSI compliant.
 *
 * December 2, 1998:
 *      Change preprocessor directive to define HAVE_STRSTR for both
 *      Linux and SGI.
 *
 * December 13, 1999:
 *      Named Version 1.0
 *
 * $Log: smake.c,v $
 * Revision 1.6  2013/08/02 13:22:09  senning
 * Use system strstr() function if __MACH__ is defined (Mac OS X)
 *
 * Revision 1.5  2012/12/11 20:13:58  senning
 * Fixed bug where newline was left at end of command
 *
 * Revision 1.4  2010/07/04 19:59:01  senning
 * - check return from system() to avoid compiler warning
 *
 * Revision 1.3  2008/05/22 13:21:00  senning
 * Increased smake line buffer from 256 to 2048 bytes
 *
 * Revision 1.2  2002/10/25 15:19:17  senning
 * Removed "prefix" and "%p".
 *
 * Revision 1.1  1999/12/16 00:33:32  senning
 * Changed escape character from bang to backslash.
 * Added code so that escaped octal numbers are supported.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>		/* needed for str...() */
#include <ctype.h>		/* needed for isspace() */

#if defined(linux) | defined(sgi) | defined(__MACH__)
#define HAVE_STRSTR
#endif

#define PNAME	"smake"		/* program name */
#define START	"$Smake:"	/* start of command marker */
#define END	"$$"		/* end of command marker */
#define FALSE   (0)
#define TRUE    (~FALSE)
#define MAXLEN  2048

#ifndef HAVE_STRSTR
char *strstr( char *s1, char *s2 )
{
    int n;

    n = strlen( s2 );

    while ( ( s1 = strchr( s1, *s2 ) ) != NULL )
    {
        if ( strncmp( s1, s2, n ) == NULL )
            break;
        s1++;
    }

    return( s1 );
}
#endif

void fsplit( char *fname, char **dir, char **file, char **ext )
/*
 * Parse filename path into its component parts.
 */
{
    char *p, *q;
    int  ch;
 
    p = strdup( fname );
    if ( ( q = strrchr( p, '/' ) ) == NULL )
    {
        *dir = NULL;
    }
    else
    {
        ch = *( ++q );
        *q = '\0';
        *dir = strdup( p );
        p = q;
        *p = ch;
    }
    *file = p;
    if ( ( q = strrchr( p, '.' ) ) != NULL )
    {
        *q = '\0';
        *ext = ++q;
    }
    else
    {
        *ext = NULL;
    }
}

char *insert( char *b, char *s )
{
    if ( s == NULL )
    {
        return( b );
    }

    while ( ( *b++ = *s++ ) )
        ;

    return( --b );
}

char *get_command( char *fname )
{
    FILE *fp;
    char buf[MAXLEN];
    static char cmd[MAXLEN];
    char *p = NULL, *b;
    char *dir, *ext, *file;
    int value;

    /*
     * Open file and scan it for the START string that indicates the
     * command to be executed.  If no marker is found then we stop.
     */

    if ( ( fp = fopen( fname, "r" ) ) == NULL )
    {
        fprintf( stderr, "%s: cannot open %s\n", PNAME, fname );
        return( NULL );
    }

    while ( fgets( buf, MAXLEN, fp ) != NULL &&
	    ( p = strstr( buf, START ) ) == NULL )
        ;

    fclose( fp );

    if ( p == NULL )
    {
        fprintf( stderr, "%s: no marker in %s\n", PNAME, fname );
        return( NULL );
    }

    fsplit( fname, &dir, &file, &ext );

    p += sizeof( START ) - 1;
    while ( isspace( *p ) )
        p++;

    b = cmd;
    while ( *p != '\n' && *p != '\r' )
    {
        if ( *p == '%' )
	{
            switch ( *( p + 1 ) )
	    {
                case 'f' : b = insert( b, fname ); p++;
                           break;
                case 'd' : b = insert( b, dir ); p++;
                           break;
                case 'x' : b = insert( b, ext ); p++;
                           break;
                case 'F' : b = insert( b, file ); p++;
                           break;
                default  : *b++ = *p;
                           break;
            }
            p++;
        }
	else if ( *p == '\\' )
	{
	    p++;
	    if ( '0' <= *p && *p <= '9' )
	    {
		value = 0;
		while ( '0' <= *p && *p <= '9' )
		{
		    value = 8 * value + ( *p - '0' );
		    p++;
		}
		*b++ = ( value % 256 );
	    }
	    else
	    {
		switch ( *p )
		{
                case 'a' : *b++ = '\a';
                           break;
                case 'n' : *b++ = '\n';
                           break;
                case 't' : *b++ = '\t';
                           break;
                case '\\' : *b++ = '\\';
                           break;
                default  : *b++ = *(--p);
                           break;
		}
		p++;
	    }
        }
	else if ( *p == '$' && *( p + 1 ) == '$' )
	{
            while ( isspace( *( --b ) ) )
                ;
            b++;
            break;
        }
	else
	{
            *b++ = *p++;
        }
    }
    *b = '\0';
    return( cmd );
}

int main( int argc, char *argv[] )
{
    char *cmd;			/* command */
    int  potent = TRUE;		/* do we really do the command or not? */

    if ( --argc != 0 && strcmp( *( ++argv ), "-n" ) == 0 )
    {
        potent = FALSE;		/* don't do command */
        argv++;
        argc--;
    }

    if ( argc == 0 )
    {
        fprintf( stderr, "Usage: %s [-n] file ...\n", PNAME );
        exit( 1 );
    }

    while ( argc-- )  /* loop over all file names supplied on command line */
    {
        if ( ( cmd = get_command( *argv ) ) != NULL )
	{
            printf( "%s\n", cmd );
            if ( potent && system( cmd ) < 0 )
            {
                fprintf( stderr, "Could not execute command: %s\n", cmd );
	    }
        }
        argv++;
    }

    return( 0 );
}
